/*
 * Copyright (C) 2014 Stratio (http://stratio.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.stratio.cassandra.lucene.search.condition;

import com.google.common.base.Objects;
import com.stratio.cassandra.lucene.IndexException;
import com.stratio.cassandra.lucene.schema.mapping.SingleColumnMapper;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.Query;

import java.util.Arrays;

/**
 * A {@link Condition} implementation that matches documents containing a value for a field.
 *
 * @author Andres de la Pena {@literal <adelapena@stratio.com>}
 */
public class ContainsCondition extends SingleColumnCondition {

    /** The default use doc values option. */
    public static final boolean DEFAULT_DOC_VALUES = false;

    /** The name of the field to be matched. */
    public final String field;

    /** The value of the field to be matched. */
    public final Object[] values;

    /** If the generated query should use doc values. */
    public final boolean docValues;

    /**
     * Constructor using the field name and the value to be matched.
     *
     * @param boost The boost for this query clause. Documents matching this clause will (in addition to the normal
     * weightings) have their score multiplied by {@code boost}.
     * @param field the name of the field to be matched
     * @param docValues if the generated query should use doc values
     * @param values the value of the field to be matched
     */
    public ContainsCondition(Float boost, String field, Boolean docValues, Object... values) {
        super(boost, field);

        if (values == null || values.length == 0) {
            throw new IndexException("Field values required");
        }

        this.field = field;
        this.docValues = docValues == null ? DEFAULT_DOC_VALUES : docValues;
        this.values = values;
    }

    /** {@inheritDoc} */
    @Override
    public Query query(SingleColumnMapper<?> mapper, Analyzer analyzer) {
        BooleanQuery.Builder builder = new BooleanQuery.Builder();
        for (Object value : values) {
            MatchCondition condition = new MatchCondition(boost, field, value, docValues);
            builder.add(condition.query(mapper, analyzer), BooleanClause.Occur.SHOULD);
        }
        return builder.build();
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                      .add("boost", boost)
                      .add("field", field)
                      .add("values", Arrays.toString(values))
                      .add("docValues", docValues)
                      .toString();
    }
}